<?php
$str_title = 'Главная';
?>
<div class="container">

<h1>LOL KEK</h1>


</div>
