<?php
    $str_title = '403 Forbidden';
?>
<div class="container">
    <div class="row">
        <div class="col s12 m2 "><h1 class="center-align" >403</h1></div>
        <div class="col s12 m10">
            <p><h5>Отказано в доступе!</h5></p>
            <p>
                Доступ к странице ограничен специальными правами.
                Для продолжения работы с сайтом воспользуйтесь основным меню или перейдите на <a href="/">главную страницу</a>.
            </p>
        </div>
    </div>
</div>