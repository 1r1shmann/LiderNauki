<?php

namespace App\Models;

use app\core\Model;

class UserRule extends Model {

    static $table_name = 'users_rules';
    static $belongs_to = array('user');

}
