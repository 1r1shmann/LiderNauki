<?php
    $str_title = '500 Internal Server Error';
?>
<div class="container">
    <div class="row">
        <div class="col s12 m2 "><h1 class="center-align" >500</h1></div>
        <div class="col s12 m10">
            <p><h5>Ошибка на сервере!</h5></p>
            <p>
                При обработке запроса произошла ошибка на сервере или превышен лимит времени обработки.
                Для продолжения работы с сайтом воспользуйтесь основным меню или перейдите на <a href="/">главную страницу</a>.
            </p>
        </div>
    </div>
</div>