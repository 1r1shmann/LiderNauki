<?php

namespace app\core;

class Model extends \ActiveRecord\Model{
    static $connection = 'production';
}
