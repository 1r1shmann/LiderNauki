<?php

namespace app\models;
use app\core\Model;

class School extends Model {
    static $table_name = 'user_schools';
    static $primary_key = 'id';
}
