<?php

namespace app\models;
use app\core\Model;

class Mentor extends Model {
    static $table_name = 'user_mentors';
    static $primary_key = 'id';
}
