<?php

namespace app\models;

use app\core\Model;

class Log extends Model {
    static $table_name = 'log';
    static $primary_key = 'id';
}
