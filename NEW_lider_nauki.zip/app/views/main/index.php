<?php
    $str_title = 'Главная';
?>
<div class="container">

</div>
