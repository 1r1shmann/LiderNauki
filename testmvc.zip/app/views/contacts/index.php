<?php
    $str_title = 'Контакты';
?>
<h1>Контакты</h1>
<p>
    icq: 199199538<br/>
    skypeid: vitalyswipe<br/>
    email: vitalyswipe@gmail.com<br/>
    <br/>

</p>
