<?php
    $str_title = 'Главная';
?>
<div class="">
    General page
</div>