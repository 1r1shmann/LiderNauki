<?php

namespace App\Core;

use App\Components\Helper;

class Controller {

    public $config;
    public $layout = 'default';

    public function __construct() {
        $this->config = new Config();
    }

    public function render($view, $data = []) {
        if (mb_strpos($view, '/')) {
            $view_path = 'app/views/' . $view . '.php';
        } else {
            $view_path = 'app/views/' . Helper::contollerFolderName(mb_strtolower($this->getClassName())) . '/' . $view . '.php';
        }

        if (file_exists($view_path)) {
            if ($data) {
                extract($data);
            }
            ob_start();
            require $view_path;
            $content = ob_get_clean();
            require 'app/views/layouts/' . $this->layout . '.php';
        } else {
            echo 'View not found';
        }
    }

    public function renderPartial($view, $data = [], $template = 'default') {
        if (mb_strpos($view, '/')) {
            $view = 'app/views/' . $view . '.php';
        } else {
            $view = 'app/views/' . Helper::contollerFolderName(mb_strtolower($this->getClassName())) . '/' . $view . '.php';
        }
        if ($data) {
            extract($data);
        }
        require $view;
    }

    public function getClassName() {
        $rf = new \ReflectionClass($this);
        return $rf->getShortName();
    }

    public function createUrl($url) {
        return '//' . $_SERVER['HTTP_HOST'] . '/' . $url;
    }

}
